1. Use the class bred, bgreen, bblue, blightblue, bviolet or borange to add background color.
2. Use the class red, green, blue, lightblue, violet, orange to add colors to text.
3. Use class "bold" to creat bold text.
4. Only call the graph/charts in the page where it is needed.
5. While working on Graphs and Charts take a look at jQuery Flot Official site - http://www.flotcharts.org
6. While working on sparklines take a look at official site of Sparklines - http://omnipotent.net/jquery.sparkline
7. Use the class wred, wgreen, wblue, blightblue, worange, wviolet along with class "widget" for colorful widgets.